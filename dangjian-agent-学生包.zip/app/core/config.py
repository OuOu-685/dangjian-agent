"""应用配置模块

支持从环境变量和配置文件加载，支持多租户配置覆盖。
"""

from functools import lru_cache
from typing import Any, Optional

from pydantic import AliasChoices, Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy.ext.asyncio import AsyncSession


class Settings(BaseSettings):
    """应用配置"""

    # ==================== 基础配置 ====================
    PROJECT_NAME: str = "党建工作智能体"
    VERSION: str = "1.0.0"
    ENV: str = Field(default="development", description="运行环境")
    DEBUG: bool = Field(default=False, description="调试模式")
    MAX_UPLOAD_SIZE: int = Field(default=10 * 1024 * 1024, gt=0, description="上传大小上限（字节）")

    # ==================== 服务配置 ====================
    HOST: str = Field(default="0.0.0.0", description="服务地址")
    # APP_PORT 是 docker-compose 使用的同一个变量名；两者取同一个值，
    # 避免"改了 .env 的 APP_PORT、应用却仍监听 8000"这种静默不一致。
    PORT: int = Field(
        default=8000,
        validation_alias=AliasChoices("PORT", "APP_PORT"),
        description="服务端口（PORT 或 APP_PORT）",
    )
    ALLOWED_HOSTS: list[str] = Field(default=["*"], description="允许的主机")

    # ==================== 安全配置 ====================
    SECRET_KEY: str = Field(
        default="dev_secret_key_change_in_production", description="应用密钥（用于 JWT 签名等）"
    )
    JWT_ALGORITHM: str = Field(default="HS256", description="JWT 签名算法")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(default=30, description="访问令牌有效期（分钟）")
    REFRESH_TOKEN_EXPIRE_DAYS: int = Field(default=7, description="刷新令牌有效期（天）")
    BCRYPT_ROUNDS: int = Field(default=12, description="密码哈希成本因子")

    # ==================== 数据库配置 ====================
    DATABASE_URL: str = Field(
        default="postgresql+asyncpg://party_user:dev_password@localhost:5432/party_agent_dev",
        description="数据库连接URL",
    )
    DB_POOL_SIZE: int = Field(default=20, description="数据库连接池大小")
    DB_MAX_OVERFLOW: int = Field(default=10, description="连接池最大溢出数")
    DB_POOL_RECYCLE: int = Field(default=3600, description="连接回收时间（秒）")

    # ==================== Redis 配置 ====================
    REDIS_URL: str = Field(default="redis://localhost:6379/0", description="Redis 连接URL")
    REDIS_POOL_SIZE: int = Field(default=10, description="Redis 连接池大小")
    REDIS_CACHE_TTL: int = Field(default=3600, description="缓存默认过期时间（秒）")

    # ==================== 会话配置 ====================
    SESSION_TTL_SECONDS: int = Field(default=3600, description="问答会话有效期（秒）")
    SESSION_MAX_TURNS: int = Field(default=5, description="会话保留的最大轮次")

    # ==================== 问答链配置 ====================
    NO_EVIDENCE_THRESHOLD: float = Field(
        default=0.5, description="无依据判定阈值（检索片段最高分低于该值视为无依据）"
    )

    # ==================== 日志配置 ====================
    LOG_LEVEL: str = Field(default="INFO", description="日志级别")
    LOG_FORMAT: str = Field(default="json", description="日志格式: json/text")

    # ==================== 模型配置 ====================
    # 阿里云 DashScope API Key（支持通义千问和DeepSeek）
    DASHSCOPE_API_KEY: Optional[str] = Field(
        default=None,
        validation_alias=AliasChoices("DASHSCOPE_API_KEY", "QWEN_API_KEY"),
        description="阿里云 DashScope API Key",
    )
    DASHSCOPE_BASE_URL: str = Field(
        default="https://dashscope.aliyuncs.com",
        description="百炼 API Host（不含接口路径；可使用业务空间地域域名）",
    )
    MODEL_TIMEOUT_SECONDS: float = Field(default=45, gt=0, description="模型调用超时（秒）")

    # LLM 模型配置
    LLM_MODEL_NAME: str = Field(
        default="deepseek-v3",
        validation_alias=AliasChoices("CHAT_MODEL", "LLM_MODEL_NAME"),
        description="LLM 模型名称",
    )
    LLM_MAX_TOKENS: int = Field(default=4096, description="LLM 最大token数")
    LLM_TEMPERATURE: float = Field(default=0.7, description="LLM 温度参数")

    # Embedding 模型配置（阿里云）
    EMBEDDING_MODEL_NAME: str = Field(
        default="qwen3.7-text-embedding-flash",
        validation_alias=AliasChoices("EMBED_MODEL", "EMBEDDING_MODEL_NAME"),
        description="向量化模型名称",
    )

    # 重排模型配置（阿里云）
    RERANKER_MODEL_NAME: str = Field(
        default="qwen3.7-text-rerank",
        validation_alias=AliasChoices("RERANK_MODEL", "RERANKER_MODEL_NAME"),
        description="重排模型名称",
    )

    # ==================== 检索配置 ====================
    RETRIEVAL_TOP_K: int = Field(default=10, description="初检条数")
    RERANK_TOP_K: int = Field(default=5, description="重排后保留条数")
    EXCLUDE_EXPIRED_BY_DEFAULT: bool = Field(default=True, description="默认排除失效文件")

    # ==================== 安全配置 ====================
    ENABLE_DATA_LEVEL_GATEWAY: bool = Field(default=True, description="启用数据级别出网闸门")
    ALLOWED_EXTERNAL_MODELS: list[str] = Field(default=[], description="允许的外部模型域名")
    ALLOWED_LOCAL_MODEL_HOSTS: list[str] = Field(default=[], description="获准的校内模型主机")

    # ==================== 业务配置 ====================
    FILE_STORAGE_DIR: str = Field(default="uploads", description="原始文件留存目录")
    FILE_ENCRYPTION_KEYS: dict[str, str] = Field(default_factory=dict, repr=False)
    FILE_ENCRYPTION_ACTIVE_KEY: str = ""
    ALLOW_LEGACY_PLAINTEXT_FILES: bool = False
    AUDIT_SPOOL_DIR: str = "audit-spool"
    AUDIT_RETENTION_DAYS: int = Field(default=365, ge=365)
    JOB_WORKER_ENABLED: bool = True
    JOB_TIMEOUT_SECONDS: int = Field(default=120, ge=10, le=3600)
    RATE_LIMIT_PER_MINUTE: int = Field(default=120, ge=1, le=10000)
    MODEL_RATE_LIMIT_PER_MINUTE: int = Field(default=20, ge=1, le=1000)
    MODEL_CALL_LIMIT_PER_MINUTE: int = Field(default=120, ge=1, le=10000)
    LOGIN_RATE_LIMIT_PER_MINUTE: int = Field(default=10, ge=1, le=100)
    ACTIVIST_TRAINING_DAYS: int = Field(default=365, description="入党积极分子培养期上限（天）")
    PROBATIONARY_PERIOD_DAYS: int = Field(default=365, description="预备党员预备期上限（天）")
    ASSESSMENT_REMINDER_SCAN_SECONDS: int = Field(
        default=300, ge=60, le=86400, description="考核站内提醒扫描周期（秒）"
    )
    MEMBER_REMINDER_SCAN_SECONDS: int = Field(
        default=3600, ge=60, le=86400, description="党员发展提醒扫描周期（秒）"
    )
    # ==================== 对外通知渠道 ====================
    # 事件→渠道的路由。默认空：不配置渠道就不外发任何消息（系统不替组织决定是否外发）。
    NOTIFICATION_ROUTES: dict[str, list[str]] = Field(
        default_factory=dict, description="事件→通知渠道路由（JSON 对象）"
    )
    NOTIFICATION_MAX_ATTEMPTS: int = Field(
        default=3, ge=1, le=10, description="单渠道投递最大尝试次数"
    )
    NOTIFICATION_BACKOFF_SECONDS: float = Field(
        default=2.0, ge=0, le=60, description="通知重试退避基数（秒），0 表示不等待"
    )

    @model_validator(mode="after")
    def production_security(self) -> "Settings":
        if self.ENV != "production":
            return self
        import base64

        from sqlalchemy.engine import make_url

        db_url = make_url(self.DATABASE_URL)
        mode = db_url.query.get("sslmode") or db_url.query.get("ssl")
        if db_url.drivername != "postgresql+asyncpg" or mode not in {
            "require",
            "verify-ca",
            "verify-full",
        }:
            raise ValueError("生产数据库必须使用明确的PostgreSQL TLS连接")
        if not self.REDIS_URL.startswith("rediss://"):
            raise ValueError("生产Redis必须使用TLS连接")
        if len(self.SECRET_KEY) < 32 or self.SECRET_KEY.startswith(("dev_", "please_change")):
            raise ValueError("生产JWT密钥必须单独配置且至少32字符")
        if not self.ALLOWED_HOSTS or "*" in self.ALLOWED_HOSTS:
            raise ValueError("生产访问来源必须明确配置")
        if (
            not self.FILE_ENCRYPTION_KEYS
            or self.FILE_ENCRYPTION_ACTIVE_KEY not in self.FILE_ENCRYPTION_KEYS
        ):
            raise ValueError("生产必须配置独立文件加密密钥环和当前版本")
        try:
            key_sizes = [
                len(base64.b64decode(key, validate=True))
                for key in self.FILE_ENCRYPTION_KEYS.values()
            ]
        except (ValueError, TypeError):
            raise ValueError("文件密钥必须为Base64编码的32字节") from None
        if any(size != 32 for size in key_sizes):
            raise ValueError("文件密钥必须为Base64编码的32字节")
        if self.ALLOW_LEGACY_PLAINTEXT_FILES:
            raise ValueError("生产服务禁止直接读取未迁移明文；请使用独立迁移工具")
        return self

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )

    @field_validator("ENV")
    @classmethod
    def validate_env(cls, v: str) -> str:
        """验证环境变量"""
        allowed = ["development", "production", "testing"]
        if v not in allowed:
            raise ValueError(f"ENV must be one of {allowed}")
        return v

    @field_validator("DATABASE_URL")
    @classmethod
    def normalize_database_url(cls, value: str) -> str:
        """兼容部署包中的 PostgreSQL URL，运行时始终使用异步驱动。"""
        for prefix in ("postgres://", "postgresql://", "postgresql+psycopg2://"):
            if value.startswith(prefix):
                return "postgresql+asyncpg://" + value[len(prefix) :]
        return value

    @field_validator("DASHSCOPE_BASE_URL")
    @classmethod
    def validate_cloud_host(cls, value: str) -> str:
        from urllib.parse import urlsplit

        parsed = urlsplit(value)
        if (
            parsed.scheme != "https"
            or not parsed.hostname
            or parsed.username
            or parsed.password
            or parsed.query
            or parsed.fragment
            or parsed.path not in ("", "/")
        ):
            raise ValueError("DASHSCOPE_BASE_URL 必须是 HTTPS API Host，不含接口路径或凭据")
        return value.rstrip("/")

    @model_validator(mode="after")
    def production_debug(self) -> "Settings":
        """生产环境不暴露调试入口或 SQL 参数。"""
        if self.ENV == "production":
            self.DEBUG = False
        return self

    @field_validator("LOG_LEVEL")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        """验证日志级别"""
        allowed = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        v = v.upper()
        if v not in allowed:
            raise ValueError(f"LOG_LEVEL must be one of {allowed}")
        return v


@lru_cache
def get_settings() -> Settings:
    """获取配置单例"""
    return Settings()


# 全局配置实例
settings = get_settings()


class TenantConfig:
    """租户级配置管理

    支持租户级配置覆盖，配置优先级：
    租户配置 > 上级租户配置 > 全局默认配置
    """

    def __init__(self) -> None:
        """初始化配置管理器"""
        self._cache: dict[str, dict[str, Any]] = {}
        self._parents: dict[str, Optional[str]] = {}

    def get(self, tenant_id: str, key: str, default: Any = None) -> Any:
        """获取租户配置

        Args:
            tenant_id: 租户ID
            key: 配置键
            default: 默认值

        Returns:
            配置值
        """
        visited: set[str] = set()
        current: str | None = tenant_id
        while current and current not in visited:
            visited.add(current)
            if key in self._cache.get(current, {}):
                return self._cache[current][key]
            current = self._parents.get(current)

        # 返回全局默认配置
        global_config = {
            "retrieval_top_k": settings.RETRIEVAL_TOP_K,
            "rerank_top_k": settings.RERANK_TOP_K,
            "no_evidence_threshold": settings.NO_EVIDENCE_THRESHOLD,
            "exclude_expired_by_default": settings.EXCLUDE_EXPIRED_BY_DEFAULT,
            "activist_training_days": settings.ACTIVIST_TRAINING_DAYS,
            "probationary_period_days": settings.PROBATIONARY_PERIOD_DAYS,
        }

        return global_config.get(key, default)

    def set(self, tenant_id: str, key: str, value: Any) -> None:
        """设置租户配置

        Args:
            tenant_id: 租户ID
            key: 配置键
            value: 配置值
        """
        if tenant_id not in self._cache:
            self._cache[tenant_id] = {}

        self._cache[tenant_id][key] = value

    def school_id(self, tenant_id: str) -> str | None:
        """只在当前祖先链查找学校，不继承平台或其他学校的审批。"""
        current: str | None = tenant_id
        visited: set[str] = set()
        while current and current not in visited:
            visited.add(current)
            if self.local(current, "_tenant_type") == "school":
                return current
            current = self._parents.get(current)
        return None

    def local(self, tenant_id: str, key: str, default: Any = None) -> Any:
        """合规确认只读取当前租户，不能继承他校或平台的审批。"""
        return self._cache.get(tenant_id, {}).get(key, default)

    async def load(self, db: AsyncSession, tenant_id: str) -> None:
        """逐请求加载当前租户及其父级，跨进程配置变更也能及时生效。"""
        from sqlalchemy import select

        from app.core.tenant import bypass_tenant_filter
        from app.models.tenant import Tenant

        current: str | None = tenant_id
        visited: set[str] = set()
        chain_active = True
        with bypass_tenant_filter():
            while current:
                if current in visited or len(visited) >= 20:
                    raise ValueError("租户配置继承存在循环或层级过深")
                visited.add(current)
                tenant = (
                    await db.execute(
                        select(Tenant).where(Tenant.id == current, Tenant.is_deleted.is_(False))
                    )
                ).scalar_one_or_none()
                self._cache[current] = dict(tenant.config or {}) if tenant else {}
                self._cache[current]["_present"] = tenant is not None
                self._cache[current]["_active"] = bool(tenant.is_active) if tenant else False
                self._cache[current]["_tenant_type"] = tenant.tenant_type if tenant else None
                self._cache[current]["_config_version"] = tenant.config_version if tenant else 0
                self._parents[current] = tenant.parent_id if tenant else None
                chain_active = chain_active and tenant is not None and bool(tenant.is_active)
                current = self._parents[current]
        self._cache[tenant_id]["_chain_active"] = chain_active

    async def save(self, db: AsyncSession, tenant_id: str, values: dict[str, Any]) -> None:
        """保留未更新键，写入数据库后重新加载；提交由调用方管理。"""
        from sqlalchemy import select

        from app.models.tenant import Tenant

        tenant = (
            await db.execute(
                select(Tenant)
                .where(Tenant.id == tenant_id)
                .with_for_update()
                .execution_options(populate_existing=True)
            )
        ).scalar_one_or_none()
        if tenant is None:
            raise LookupError("当前账号所属租户尚未登记，请先完成租户初始化")
        tenant.config = {**(tenant.config or {}), **values}
        from app.core.tenant import current_user_id
        from app.models.governance import ConfigRevision

        tenant.config_version += 1
        db.add(
            ConfigRevision(
                tenant_id=tenant_id,
                version=tenant.config_version,
                actor_id=current_user_id.get() or "maintenance",
                reason="维护租户业务配置",
                values=dict(tenant.config),
            )
        )
        await db.flush()
        await self.load(db, tenant_id)

    def reload(self, tenant_id: str) -> None:
        """重新加载租户配置

        Args:
            tenant_id: 租户ID
        """
        # 清除缓存
        if tenant_id in self._cache:
            del self._cache[tenant_id]
        self._parents.pop(tenant_id, None)


# 全局租户配置管理器
tenant_config = TenantConfig()
